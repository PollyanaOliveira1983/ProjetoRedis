package SoulCode.ProjetoRedis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoRedisApplicationTests {

	@Test
	void contextLoads() {
	}

}
